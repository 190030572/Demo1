module.exports = (sequelize, DataTypes) => {

    const Branch = sequelize.define("branch", {

        name: {
            type: DataTypes.STRING,
            allowNull: false
        },
        branch_id: {
            type: DataTypes.INTEGER
        }
    
    })

    return Branch

}