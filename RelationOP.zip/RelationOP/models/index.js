const dbConfig = require('../config/db.config');

const {Sequelize, DataTypes, STRING} = require('sequelize');

const sequelize = new Sequelize(
    dbConfig.DB,
    dbConfig.USER,
    dbConfig.PASSWORD, {
        host: dbConfig.HOST,
        dialect: dbConfig.dialect,
        operatorsAliases: STRING,

        pool: {
            max: dbConfig.pool.max,
            min: dbConfig.pool.min,
            acquire: dbConfig.pool.acquire,
            idle: dbConfig.pool.idle

        }
    }
)

sequelize.authenticate()
.then(() => {
    console.log('connected..')
})
.catch(err => {
    console.log('Error'+ err)
})

const db = {}

db.Sequelize = Sequelize
db.sequelize = sequelize

db.branch = require('./branchModel')(sequelize, DataTypes)
db.students = require('./studentModel')(sequelize, DataTypes)


db.sequelize.sync({ force: false })
.then(() => {
    console.log('yes re-sync done!')
})

db.branch.hasMany(db.students, {
    foreignKey: 'student_id',
    as: 'student'
})

db.stu.belongsTo(db.branch, {
    foreignKey: 'student_id',
    as: 'branch'
})

module.exports = db

