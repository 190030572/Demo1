const db = require('../models')

const Branch = db.branch


// main work

// 1. create branch

const addBranch = async (req, res) => {

    let info = {
       
        name: req.body.name,
        branch_id: req.body.branch_id,
        
        
    }

    const branch = await Branch.create(info)
    res.status(200).send(branch)
    console.log(branch)

}



// 2. get all branches

const getAllBranches = async (req, res) => {

    let branches = await Branch.findAll({})
    res.status(200).send(branches)

}

// 3. get single branch

const getOneBranch = async (req, res) => {

    let id = req.params.id
    let branch = await Branch.findOne({ where: { id: id }})
    res.status(200).send(branch)

}

// 4. update branch

const updateBranch = async (req, res) => {

    let id = req.params.id

    const branch = await Branch.update(req.body, { where: { id: id }})

    res.status(200).send(branch)
   

}

// 5. delete branch by id

const deleteBranch = async (req, res) => {

    let id = req.params.id
    
    await Branch.destroy({ where: { id: id }} )

    res.status(200).send('Branch is deleted !')

}

const getBranchStudents =  async (req, res) => {

    const id = req.params.id

    const data = await Branch.findOne({
        include: [{
            model: Student,
            as: 'student'
        }],
        where: { id: id }
    })

    res.status(200).send(data)

}


module.exports = {
    addBranch,
    getAllBranches,
    getOneBranch,
    updateBranch,
    deleteBranch,
    getBranchStudents,    
}