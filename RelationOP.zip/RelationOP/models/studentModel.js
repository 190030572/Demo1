module.exports = (sequelize, DataTypes) => {

    const Student = sequelize.define("student", {
        branch_id: {
            type: DataTypes.INTEGER
        },
        student_name: {
            type: DataTypes.STRING
        }
    })

    return Student

}