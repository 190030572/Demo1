// import controllers review, products
const branchController = require('../controllers/branchController')
const studentController = require('../controllers/studentController')


// router
const router = require('express').Router()


// use routers
router.post('/addBranch', branchController.addBranch)

router.get('/allBranches', branchController.getAllBranches)




// Review Url and Controller

router.get('/allStudents', studentController.getAllStudents)
router.post('/addStudent', studentController.addStudent)

// get branch students relation
router.get('/getBranchStudents/:id', branchController.getBranchStudents)




// Branch router
router.get('/:id', branchController.getOneBranch)

router.put('/:id', branchController.updateBranch)

router.delete('/:id', branchController.deleteBranch)

module.exports = router