const db = require('../models')

// model
const Student = db.students

// functions

//1. Add Student

const addStudent = async (req, res) => {

    const id = req.params.id

    let data = {
        student_id:id,
        student_name: req.body.student_name,
       
    }

    const student = await Student.create(data)
    res.status(200).send(student)
    console.log(student)

}

// 2. Get All Students

const getAllStudents= async (req, res) => {

    const students = await Student.findAll({})
    res.status(200).send(students)

}

module.exports = {
    addStudent,
    getAllStudents
}